# Data files for the *WetPaper* project

## Fonts
- The Modak font is distributed under the *SIL Open Font License, Version 1.1*

## Sounds
- The bubble sounds have been recorded by Angelo "Encelo" Theodorou and are distributed under the *CC BY-NC-SA 4.0 License*
- The user interface sounds have been recorded by Angelo "Encelo" Theodorou and are distributed under the *CC BY-NC-SA 4.0 License*

## Music
- "[09 Lunar Rush](https://freemusicarchive.org/music/maxim-novak/best-of-2024-listeners-choice/09-lunar-rush/)" by Maxim Novak is licensed under an Attribution-NonCommercial-NoDerivatives 4.0 International License.
- "[Alone at Night.mp3](https://freemusicarchive.org/music/serge-quadrado/hidden-ost/alone-at-nightmp3/)" by Serge Quadrado is licensed under an Attribution-NonCommercial 4.0 International License.

## Textures
- The nCine logo is part of the nCine project and is distributed under the terms of the *CC BY-SA 4.0 International License*
- The textures have been created by "awachirri88" and "JustABallOfAnger" and are distributed under the *CC BY-NC-SA 4.0 License*
